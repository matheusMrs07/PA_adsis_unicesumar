package com.adsis.exemploSpring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExemploSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExemploSpringApplication.class, args);
	}

}
