package com.adsis.exemploSpring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExemploSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
